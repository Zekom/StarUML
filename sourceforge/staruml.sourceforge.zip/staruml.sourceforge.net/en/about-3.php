<html>
<head>
	<title>StarUML - The Open Source UML/MDA Platform</title>
	<link rel="stylesheet" type="text/css" href="../css/staruml.css"/>
</head>
<body>

<div id="wrap">

<div id="header">
	<table width="100%">
		<tr>
			<td width="28%">
				<a href="index.php"><img src="../image/logo-staruml.gif"></a>
			</td width="28%">
			<td>
				<script type="text/javascript"><!--
				google_ad_client = "pub-2992470876807993";
				google_ad_width = 468;
				google_ad_height = 60;
				google_ad_format = "468x60_as";
				google_ad_type = "text_image";
				google_ad_channel ="";
				google_color_border = "6699CC";
				google_color_bg = "003366";
				google_color_link = "FFFFFF";
				google_color_text = "AECCEB";
				google_color_url = "AECCEB";
				//--></script>
				<script type="text/javascript"
				  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>
			</td>
			<td valign="top" align="right" style="padding: 15px 15px 15px 15px">
				<p><font color="white">English |</font>
				<a href="../ko/"><font color="white">Korean</font></a></p>
			</td>
		</tr>
	</table>
</div>

<div id="main-body">
<div id="left">
<div class="container">
	<ul>
		<li><b>Project</b>
		<li><a href="about.php">About</a>
		<li><a href="https://sourceforge.net/project/screenshots.php?group_id=152825">Screenshots</a>
		<li><a href="case-study.php">Case Study</a>
		<li><a href="roadmap.php">Roadmap</a>
		<li><a href="contributing.php">Contributing</a>
		<li><a href="development.php">Development</a>
		<li><b>Downloads</b>
		<li><a href="download.php">StarUML Download</a>
		<li><a href="modules.php">Modules</a>
		<li><a href="templates.php">Templates</a>
		<li><b>Support</b>
		<li><a href="https://sourceforge.net/forum/?group_id=152825">Forum</a>
		<li><a href="documentations.php">Documentations</a>
		<li><a href="articles.php">Articles</a>		
		<li><a href="commercial-support.php">Commercial Support</a>
		<li><a href="links.php">Links</a>
	</ul>
</div>
<br>
<div class="container" align="center">
<b>New Book</b><br>
<a href="http://www.lulu.com/content/1221482">Generating MS-Word Document with StarUML</a><br>
<a href="http://www.lulu.com/content/1221482"><img src="../image/worddocgenbook.jpg" class="icon"></a>
</div>
<br>
<script type="text/javascript"><!--
google_ad_client = "pub-2992470876807993";
google_ad_width = 160;
google_ad_height = 90;
google_ad_format = "160x90_0ads_al";
google_ad_channel = "";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

</div>
<div id="content">
	<H1>About StarUML&nbsp; </H1>
	
	<UL id="minitabs">
		<LI><A href="about.php">Summary</A></LI>
		<LI><A href="about-2.php">Features</A></LI>
		<LI><A href="about-3.php"class="active">History</A></LI>
		<LI><A href="license.php">License</A></LI>
	</UL>

	<P><I>* StarUML is formerly known as "Plastic" or "Agora Plastic".</I></P>
	<P>
	<TABLE id=table1 cellSpacing=0 cellPadding=0 border=0>
	<TBODY>
	<TR>
	<TD vAlign=top width=55 bgColor=#eeeeee>1996</TD>
	<TD vAlign=top bgColor=#eeeeee>The first version (v0.9)&nbsp;of Plastic was born.<BR>It was very simple tool that is used to draw software modules and their dependencies.</TD></TR>
	<TR>
	<TD vAlign=top width=55>1997</TD>
	<TD vAlign=top>Plastic 1.0 released.<BR>Freeware, OMT supported, Grand prize of software contest&nbsp;held by Hyundai.</TD></TR>
	<TR>
	<TD vAlign=top width=55 bgColor=#eeeeee>1998</TD>
	<TD vAlign=top bgColor=#eeeeee>Plastic 1.1 released.<BR>UML class diagram supported</TD></TR>
	<TR>
	<TD vAlign=top width=55>1999</TD>
	<TD vAlign=top>
	<P>Foundation of Plastic Software, Inc.<BR>Plastic 2.0 released.<BR>UML supported, Java code generation and reverse engineering</P></TD></TR>
	<TR>
	<TD vAlign=top width=55 bgColor=#eeeeee>2001</TD>
	<TD vAlign=top bgColor=#eeeeee>Plastic 3.0 released.<BR>UML 1.3 fully supported</TD></TR>
	<TR>
	<TD vAlign=top width=55>2003</TD>
	<TD vAlign=top>Plastic 2003 released.<BR>Completely redesigned and rewritten, UML 1.4 fully supported, open architecture.</TD></TR>
	<TR>
	<TD vAlign=top width=55 bgColor=#eeeeee>2005</TD>
	<TD vAlign=top bgColor=#eeeeee>Agora Plastic 2005 released.<BR>Internationalized, many features are implemented on extensible platform.<BR>'Good Software' Certified from The Ministry of Information and Communications&nbsp;of Korea.</TD></TR>
	<TR>
	<TD vAlign=top width=55>2005</TD>
	<TD vAlign=top>StarUML 5.0 renamed and released.<BR>turned to open source project, UML 2.0 supported, and notation extension technology was implemented.</TD></TR></TBODY></TABLE>&nbsp;</P></SPAN>
</div>

<div id="right">
	<SCRIPT type=text/javascript><!--
	google_ad_client = "pub-2992470876807993";
	google_ad_width = 160;
	google_ad_height = 600;
	google_ad_format = "160x600_as";
	google_ad_type = "text_image";
	google_ad_channel ="";
	google_color_border = "336699";
	google_color_bg = "FFFFFF";
	google_color_link = "0000FF";
	google_color_url = "008000";
	google_color_text = "000000";
	//--></SCRIPT>
	
	<SCRIPT src="http://pagead2.googlesyndication.com/pagead/show_ads.js" type=text/javascript>
	</SCRIPT>
</div>

</div> <!-- of <div id="main-body"> -->
</div> <!-- of <div id="wrap"> -->

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-104513-2";
urchinTracker();
</script>

</body>
</html>

