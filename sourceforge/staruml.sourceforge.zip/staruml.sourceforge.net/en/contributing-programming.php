<html>
<head>
	<title>StarUML - The Open Source UML/MDA Platform</title>
	<link rel="stylesheet" type="text/css" href="../css/staruml.css"/>
</head>
<body>

<div id="wrap">

<div id="header">
	<table width="100%">
		<tr>
			<td width="28%">
				<a href="index.php"><img src="../image/logo-staruml.gif"></a>
			</td width="28%">
			<td>
				<script type="text/javascript"><!--
				google_ad_client = "pub-2992470876807993";
				google_ad_width = 468;
				google_ad_height = 60;
				google_ad_format = "468x60_as";
				google_ad_type = "text_image";
				google_ad_channel ="";
				google_color_border = "6699CC";
				google_color_bg = "003366";
				google_color_link = "FFFFFF";
				google_color_text = "AECCEB";
				google_color_url = "AECCEB";
				//--></script>
				<script type="text/javascript"
				  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>
			</td>
			<td valign="top" align="right" style="padding: 15px 15px 15px 15px">
				<p><font color="white">English |</font>
				<a href="../ko/"><font color="white">Korean</font></a></p>
			</td>
		</tr>
	</table>
</div>

<div id="main-body">
<div id="left">
<div class="container">
	<ul>
		<li><b>Project</b>
		<li><a href="about.php">About</a>
		<li><a href="https://sourceforge.net/project/screenshots.php?group_id=152825">Screenshots</a>
		<li><a href="case-study.php">Case Study</a>
		<li><a href="roadmap.php">Roadmap</a>
		<li><a href="contributing.php">Contributing</a>
		<li><a href="development.php">Development</a>
		<li><b>Downloads</b>
		<li><a href="download.php">StarUML Download</a>
		<li><a href="modules.php">Modules</a>
		<li><a href="templates.php">Templates</a>
		<li><b>Support</b>
		<li><a href="https://sourceforge.net/forum/?group_id=152825">Forum</a>
		<li><a href="documentations.php">Documentations</a>
		<li><a href="articles.php">Articles</a>		
		<li><a href="commercial-support.php">Commercial Support</a>
		<li><a href="links.php">Links</a>
	</ul>
</div>
<br>
<div class="container" align="center">
<b>New Book</b><br>
<a href="http://www.lulu.com/content/1221482">Generating MS-Word Document with StarUML</a><br>
<a href="http://www.lulu.com/content/1221482"><img src="../image/worddocgenbook.jpg" class="icon"></a>
</div>
<br>
<script type="text/javascript"><!--
google_ad_client = "pub-2992470876807993";
google_ad_width = 160;
google_ad_height = 90;
google_ad_format = "160x90_0ads_al";
google_ad_channel = "";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

</div>
<div id="content">
	<H1>Contributing by Programming</H1>
	<P>StarUML is mostly written in Delphi.&nbsp;However, <STRONG>StarUML is multi-lingual<EM> </EM>project and&nbsp;not tied to specific programming language</STRONG>, so&nbsp;various programming languages&nbsp;can be used to develop StarUML. (for example,&nbsp;C/C++,&nbsp;Visual Basic, Delphi, JScript, VBScript, C#, VB.NET, ...)&nbsp;</P>
	<P>Here are some areas where you can contribute by programming:</P>
	<H3>Developing a New Module</H3>
	<OL>
	<LI>Write your own a new module. (Refer to&nbsp;<A href="../docs/developer-guide(en)/toc.html" target="_blank">Developer's Guide</A>) 
	<LI>Zip it and send it us. (<STRONG>staruml@gmail.com</STRONG>) 
	<LI>We will upload it to this web-site.</LI></OL>
	<H3>Implementing Features</H3>
	<P dir=ltr style="MARGIN-RIGHT: 0px"><STRONG><FONT color=#ff0000>We strongly recommend write your&nbsp;idea as a new module rather than extending core source code.</FONT></STRONG></P>
	<OL>
	<LI>Checkout the project source code using CVS client
	<LI>Write your own version of StarUML with new features. 
	<LI>Test it. 
	<LI>Send it us binaries and source codes (<STRONG>staruml@gmail.com</STRONG>) 
	<LI>We will merge it with main stream of source code. 
	<LI>Release it on next release.</LI></OL>
	<P>If you have questions about Programming, please contact <STRONG>staruml@gmail.com</STRONG>.</P>

</div>

<div id="right">
	<SCRIPT type=text/javascript><!--
	google_ad_client = "pub-2992470876807993";
	google_ad_width = 160;
	google_ad_height = 600;
	google_ad_format = "160x600_as";
	google_ad_type = "text_image";
	google_ad_channel ="";
	google_color_border = "336699";
	google_color_bg = "FFFFFF";
	google_color_link = "0000FF";
	google_color_url = "008000";
	google_color_text = "000000";
	//--></SCRIPT>
	
	<SCRIPT src="http://pagead2.googlesyndication.com/pagead/show_ads.js" type=text/javascript>
	</SCRIPT>
</div>

</div> <!-- of <div id="main-body"> -->
</div> <!-- of <div id="wrap"> -->

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-104513-2";
urchinTracker();
</script>

</body>
</html>

