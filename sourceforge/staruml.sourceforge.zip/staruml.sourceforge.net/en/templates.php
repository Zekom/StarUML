<html>
<head>
	<title>StarUML - The Open Source UML/MDA Platform</title>
	<link rel="stylesheet" type="text/css" href="../css/staruml.css"/>
</head>
<body>

<div id="wrap">

<div id="header">
	<table width="100%">
		<tr>
			<td width="28%">
				<a href="index.php"><img src="../image/logo-staruml.gif"></a>
			</td width="28%">
			<td>
				<script type="text/javascript"><!--
				google_ad_client = "pub-2992470876807993";
				google_ad_width = 468;
				google_ad_height = 60;
				google_ad_format = "468x60_as";
				google_ad_type = "text_image";
				google_ad_channel ="";
				google_color_border = "6699CC";
				google_color_bg = "003366";
				google_color_link = "FFFFFF";
				google_color_text = "AECCEB";
				google_color_url = "AECCEB";
				//--></script>
				<script type="text/javascript"
				  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>
			</td>
			<td valign="top" align="right" style="padding: 15px 15px 15px 15px">
				<p><font color="white">English |</font>
				<a href="../ko/"><font color="white">Korean</font></a></p>
			</td>
		</tr>
	</table>
</div>

<div id="main-body">
<div id="left">
<div class="container">
	<ul>
		<li><b>Project</b>
		<li><a href="about.php">About</a>
		<li><a href="https://sourceforge.net/project/screenshots.php?group_id=152825">Screenshots</a>
		<li><a href="case-study.php">Case Study</a>
		<li><a href="roadmap.php">Roadmap</a>
		<li><a href="contributing.php">Contributing</a>
		<li><a href="development.php">Development</a>
		<li><b>Downloads</b>
		<li><a href="download.php">StarUML Download</a>
		<li><a href="modules.php">Modules</a>
		<li><a href="templates.php">Templates</a>
		<li><b>Support</b>
		<li><a href="https://sourceforge.net/forum/?group_id=152825">Forum</a>
		<li><a href="documentations.php">Documentations</a>
		<li><a href="articles.php">Articles</a>		
		<li><a href="commercial-support.php">Commercial Support</a>
		<li><a href="links.php">Links</a>
	</ul>
</div>
<br>
<div class="container" align="center">
<b>New Book</b><br>
<a href="http://www.lulu.com/content/1221482">Generating MS-Word Document with StarUML</a><br>
<a href="http://www.lulu.com/content/1221482"><img src="../image/worddocgenbook.jpg" class="icon"></a>
</div>
<br>
<script type="text/javascript"><!--
google_ad_client = "pub-2992470876807993";
google_ad_width = 160;
google_ad_height = 90;
google_ad_format = "160x90_0ads_al";
google_ad_channel = "";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

</div>
<div id="content">
	<h1>Templates</h1>
	<div class="container">
	<ul>
		<li><b>PHP 5 Code Generator Template (<a href="../files/PHP_5_Code_Generator.zip">PHP_5_Code_Generator.zip</a>)</b><br>
		It generates Php 5 class structure (provided by Daniel Ramotowski[daniura@wp.pl]).
		<li><b>text-template example (<a href="../files/template-text.zip">template-text.zip</a>)</b><br>
		This sample template is used in developer-guide.
		<li><b>powerpoint-template example (<a href="../files/template-powerpoint.zip">template-powerpoint.zip</a>)</b><br>
		This sample template is used in developer-guide.
		<li><b>excel-template example (<a href="../files/template-excel.zip">template-excel.zip</a>)</b><br>
		This sample template is used in developer-guide.
		<li><b>word-template example (<a href="../files/template-word.zip">template-word.zip</a>)</b><br>
		This sample template is used in developer-guide.
	</ul>
	</div>
	<H1>How to install a template?</H1>
	<P>Installing a template is very simple.</P>
	<OL>
	<LI>Download a&nbsp;template distribution package (.zip) 
	<LI>Extract the file on StarUML&nbsp;template directory (e.g. C:\Program Files\StarUML\modules\staruml-generator\templates)</LI></OL></SPAN>

	<H1>How to register my template in the catalogue? </H1>
	<P>If you'd like to list it in the&nbsp;Template Catalogue ! Please copy-paste the following info into an email, and send it to&nbsp;<b>staruml@gmail.com</b>, and we'll add you to the catalogue. </P>
	<P>Please note - all fields are required! We will not be able to list your&nbsp;template without complete info. Thanks. </P>
	<OL>
	<LI>Template&nbsp;name : 
	<LI>Brief Description&nbsp; : 
	<LI>Status : Stable / Beta / Alpha 
	<LI>For&nbsp;StarUML Version : (specific&nbsp;StarUML release numbers like 5.0, or "any") 
	<LI>Template&nbsp;Version : (eg v1.3, or "community edition") 
	<LI>Contact email : (will not appear in the live Catalogue, only so we can contact you for updates!) 
	<LI>File (Please attach the zipped template distribution package file)</LI></OL>
</div>

<div id="right">
	<SCRIPT type=text/javascript><!--
	google_ad_client = "pub-2992470876807993";
	google_ad_width = 160;
	google_ad_height = 600;
	google_ad_format = "160x600_as";
	google_ad_type = "text_image";
	google_ad_channel ="";
	google_color_border = "336699";
	google_color_bg = "FFFFFF";
	google_color_link = "0000FF";
	google_color_url = "008000";
	google_color_text = "000000";
	//--></SCRIPT>
	
	<SCRIPT src="http://pagead2.googlesyndication.com/pagead/show_ads.js" type=text/javascript>
	</SCRIPT>
</div>

</div> <!-- of <div id="main-body"> -->
</div> <!-- of <div id="wrap"> -->

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-104513-2";
urchinTracker();
</script>

</body>
</html>

