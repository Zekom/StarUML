<html>
<head>
	<title>StarUML - The Open Source UML/MDA Platform</title>
	<link rel="stylesheet" type="text/css" href="../css/staruml.css"/>
</head>
<body>

<div id="wrap">

<div id="header">
	<table width="100%">
		<tr>
			<td width="28%">
				<a href="index.php"><img src="../image/logo-staruml.gif"></a>
			</td width="28%">
			<td>
				<script type="text/javascript"><!--
				google_ad_client = "pub-2992470876807993";
				google_ad_width = 468;
				google_ad_height = 60;
				google_ad_format = "468x60_as";
				google_ad_type = "text_image";
				google_ad_channel ="";
				google_color_border = "6699CC";
				google_color_bg = "003366";
				google_color_link = "FFFFFF";
				google_color_text = "AECCEB";
				google_color_url = "AECCEB";
				//--></script>
				<script type="text/javascript"
				  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>
			</td>
			<td valign="top" align="right" style="padding: 15px 15px 15px 15px">
				<p><font color="white">English |</font>
				<a href="../ko/"><font color="white">Korean</font></a></p>
			</td>
		</tr>
	</table>
</div>

<div id="main-body">
<div id="left">
<div class="container">
	<ul>
		<li><b>Project</b>
		<li><a href="about.php">About</a>
		<li><a href="https://sourceforge.net/project/screenshots.php?group_id=152825">Screenshots</a>
		<li><a href="case-study.php">Case Study</a>
		<li><a href="roadmap.php">Roadmap</a>
		<li><a href="contributing.php">Contributing</a>
		<li><a href="development.php">Development</a>
		<li><b>Downloads</b>
		<li><a href="download.php">StarUML Download</a>
		<li><a href="modules.php">Modules</a>
		<li><a href="templates.php">Templates</a>
		<li><b>Support</b>
		<li><a href="https://sourceforge.net/forum/?group_id=152825">Forum</a>
		<li><a href="documentations.php">Documentations</a>
		<li><a href="articles.php">Articles</a>		
		<li><a href="commercial-support.php">Commercial Support</a>
		<li><a href="links.php">Links</a>
	</ul>
</div>
<br>
<div class="container" align="center">
<b>New Book</b><br>
<a href="http://www.lulu.com/content/1221482">Generating MS-Word Document with StarUML</a><br>
<a href="http://www.lulu.com/content/1221482"><img src="../image/worddocgenbook.jpg" class="icon"></a>
</div>
<br>
<script type="text/javascript"><!--
google_ad_client = "pub-2992470876807993";
google_ad_width = 160;
google_ad_height = 90;
google_ad_format = "160x90_0ads_al";
google_ad_channel = "";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

</div>
<div id="content">
	<h1>Modules</h1>
	<div class="container">

		<table cellpadding="3">
			<tr>
				<td valign="top">
					<img src="../image/staruml-spem.jpg" class="icon">
				</td>
				<td valign="top">
					<b>SPEM - Software Process Engineering Metamodel</b><br>
             This module is an implementation of the UML 2.0 Profile named SPEM - Software Process Engineering Metamodel, developded by OMG(www.omg.org). The SPEM Profile supports the production of models for the modeling of software process, including roles, tasks, work products. The profile implements all features of the Final Adopted Specification (ptc/07-03-03) of OMG SPEM.<br>
					<i>Contributed by Clayton  Vieira Fraga Filho. Software Engineering Researcher and Teacher - Brazil 
(contact: claytonfraga@gmail.com)
</i><br>
					<img src="../image/zip.gif" align="middle"><a href="../files/staruml-spem.zip">staruml-spem.zip</a> (64KB)<br>
          <a href="../image/staruml-spem-screenshot.jpg" target="_blank">screenshot<a>
				</td>
			</tr>
		</table>
		<hr size="1">
		<table cellpadding="3">
			<tr>
				<td valign="top">
					<img src="../image/softgoal-profile.jpg" class="icon">
				</td>
				<td valign="top">
					<b>The Softgoal Profile</b><br>
             This module supports non-functional requirements (NFRs) modeling based on the notations from the NFR framework where NFRs can be explicitly represented as softgoals. The NFRs as softgoals may be further refined using AND/OR decompositions, and traced to design alternatives. <a href="http://www.utdallas.edu/~supakkul/tools/softgoal-profile/softgoal-profile.html">(for more information...)</a><br>
					<i>Contributed by Sam Supakkul (ssupakkul@ieee.org)</i><br>
					<img src="../image/zip.gif" align="middle"> <a href="http://www.utdallas.edu/~supakkul/tools/softgoal-profile/softgoal-profile-11.zip">softgoal-profile-11.zip</a> (22KB)<br>
          <a href="../image/softgoal-profile-screenshot.jpg" target="_blank">screenshot<a>
				</td>
			</tr>
		</table>
		<hr size="1">
		<table cellpadding="3">
			<tr>
				<td valign="top">
					<img src="../image/staruml-WAE.jpg" class="icon">
				</td>
				<td valign="top">
					<b>Web Application Extension (WAE) Profile</b><br>
             As part of a project grade, in the area of systems analysis and design of the Simon Bolivar University of Venezuela, have added two modules to StarUML, implementing an extension of notation that allows diagrams WAE (Web Application Extension), class and sequence. <br>
					<i>Contributed by Orlando Alfonzo (oras14@gmail.com) and Kenyer Dominguez (kenyer@gmail.com)</i><br>
					<img src="../image/zip.gif" align="middle"> <a href="../files/staruml-WAEClass.zip">staruml-WAEClass.zip</a> (90KB),
					<img src="../image/zip.gif" align="middle"> <a href="../files/staruml-WAESequence.zip">staruml-WAESequence.zip</a> (90KB)<br>
				</td>
			</tr>
		</table>
		<hr size="1">
		<table cellpadding="3">
			<tr>
				<td valign="top">
					<img src="../image/aml-profile.jpg" class="icon">
				</td>
				<td valign="top">
					<b>AML (Agent Modeling Language) Profile</b><br>
					This module is an implementation of the UML 2.0 Profile for the Agent
                    Modeling Language (AML). The AML Profile supports the production of AML
                    models for the analysis and design disciplines of software application
                    development, especially where applications draw on multi-agent systems
                    theory and engineering practice. The profile implements all features of
                    the version 0.9 of AML, which offers support for: multi-agent system
                    entities, ontologies, social aspects, behavior abstraction and
                    decomposition, communicative interactions, services, observations and
                    effecting interactions, mental aspects, deployment, and mobility.
                    (License: Modified BSD)<br>
					<i>Contributed by Radovan Cervenka(rce@whitestein.com), Whitestein Technologies</i><br>
					<img src="../image/zip.gif" align="middle"> <a href="http://www.whitestein.com/library/company-and-product-resources#methodology">Link to Download (installer, examples, documents, ...)</a><br>
					<a href="../image/aml-profile-screenshot.jpg" target="_blank">screenshot<a>
				</td>
			</tr>
		</table>
		<hr size="1">
		<table cellpadding="3">
			<tr>
				<td valign="top">
					<img src="../image/staruml-epbe.jpg" class="icon">
				</td>
				<td valign="top">
					<b>Eriksson-Penker Business Extensions (EPBE) v1.0</b><br>
					A business processing model extension from UML, developed by Hans-Erik Eriksson and Magnus Penker. The Eriksson-Penker Business Extensions form a basic framework for business extensions to UML to which a business architect can add stereotypes or properties suitable to his or her line of business. This module is created from a course about systems analysis and design in the University of Natural Sciences. (License: SPL)<br>
					<i>Contributed by Pham Ngoc Viet Phuong (phuongphamnv@gmail.com)</i><br>
					<img src="../image/zip.gif" align="middle"> <a href="../files/staruml-epbm.zip">staruml-epbm.zip</a> (30KB)<br>
					<a href="../image/staruml-epbe-screenshot1.jpg" target="_blank">screenshot-1<a> | <a href="../image/staruml-epbe-screenshot2.jpg" target="_blank">screenshot-2</a>
				</td>
			</tr>
		</table>
		<hr size="1">
		<table cellpadding="3">
			<tr>
				<td valign="top">
					<img src="../image/word-template-designer.jpg" class="icon">
				</td>
				<td valign="top">
					<b>Word Template Designer v1.0</b><br>
					This module is very useful to define Microsoft Word Template for StarUML Generator. It interoperates with both StarUML and Microsoft Word. It requires Microsoft Word XP or 2003. After installation of this module, you can find a new menu item [Tools]->[Word Template Designer] in StarUML.<br>
					<img src="../image/zip.gif" align="middle"> <a href="../files/staruml-wordtemplatedesigner.zip">staruml-wordtemplatedesigner.zip</a> (761KB)<br>
					<a href="../image/word-template-designer-screenshot.jpg" target="_blank">screenshot<a>
				</td>
			</tr>
		</table>
		<hr size="1">
		<table cellpadding="3">
			<tr>
				<td valign="top">
					<img src="../image/er-diagram-example.jpg" class="icon">
				</td>
				<td valign="top">
					<b>Notation Extension Example - ER Diagram</b><br>
					This module is application of Notation Extension. On StarUML, ER Diagram is possible. Really Entity-Relation Diagram Modeling. This is the example module which is explained in StarUML developer-guide chapter 10.<br>
					<img src="../image/zip.gif" align="middle"> <a href="../files/staruml-erd.zip">staruml-erd.zip</a> (11KB)<br>
				</td>
			</tr>
		</table>

	</div>
	<H1>How to install a module?</H1>
	<P>Installing a module is very simple.</P>
	<OL>
	<LI>Download a module distribution package (.zip) 
	<LI>Extract the file on StarUML module directory (e.g. C:\Program Files\StarUML\modules)</LI></OL>

	<H1>How to register my modules in the catalogue? </H1>
	<P>If you have a module hosted somewhere, be it your company website, your personal homepage or somewhere like SourceForge or Tigris.org, we'd like to list it in the Module Catalogue ! Please copy-paste the following info into an email, and send it to&nbsp;<A href="mailto:staruml@gmail.com">staruml@gmail.com</A>, and we'll add you to the catalogue. </P>
	<P>Please note - all fields are required! We will not be able to list your module without complete info. Thanks. </P>
	<OL>
	<LI>Module name : 
	<LI>Brief Description (1 sentence) : 
	<LI>Long Description (short paragraph) : 
	<LI>Homepage/info URL : http:// 
	<LI>License : SPL / Shareware / Commercial / Other (specify) 
	<LI>Download URL : http:// 
	<LI>Module Status : Stable / Beta / Alpha 
	<LI>Price : 
	<LI>For&nbsp;StarUML Version : (specific&nbsp;StarUML release numbers like 5.0, or "any") 
	<LI>Module Version : (eg v1.3, or "community edition") 
	<LI>Filesize : 
	<LI>Contact email : (will not appear in the live Catalogue, only so we can contact you for updates!) 
	<LI>Screenshot : (Optional. please attach the screenshot image file.)</LI></OL>
</div>

<div id="right">
	<SCRIPT type=text/javascript><!--
	google_ad_client = "pub-2992470876807993";
	google_ad_width = 160;
	google_ad_height = 600;
	google_ad_format = "160x600_as";
	google_ad_type = "text_image";
	google_ad_channel ="";
	google_color_border = "336699";
	google_color_bg = "FFFFFF";
	google_color_link = "0000FF";
	google_color_url = "008000";
	google_color_text = "000000";
	//--></SCRIPT>
	
	<SCRIPT src="http://pagead2.googlesyndication.com/pagead/show_ads.js" type=text/javascript>
	</SCRIPT>
</div>

</div> <!-- of <div id="main-body"> -->
</div> <!-- of <div id="wrap"> -->

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-104513-2";
urchinTracker();
</script>

</body>
</html>

