<html>
<head>
	<title>StarUML - The Open Source UML/MDA Platform</title>
	<link rel="stylesheet" type="text/css" href="../css/staruml.css"/>
</head>
<body>

<div id="wrap">

<div id="header">
	<table width="100%">
		<tr>
			<td width="28%">
				<a href="index.php"><img src="../image/logo-staruml.gif"></a>
			</td width="28%">
			<td>
				<script type="text/javascript"><!--
				google_ad_client = "pub-2992470876807993";
				google_ad_width = 468;
				google_ad_height = 60;
				google_ad_format = "468x60_as";
				google_ad_type = "text_image";
				google_ad_channel ="";
				google_color_border = "6699CC";
				google_color_bg = "003366";
				google_color_link = "FFFFFF";
				google_color_text = "AECCEB";
				google_color_url = "AECCEB";
				//--></script>
				<script type="text/javascript"
				  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>
			</td>
			<td valign="top" align="right" style="padding: 15px 15px 15px 15px">
				<p><font color="white">English |</font>
				<a href="../ko/"><font color="white">Korean</font></a></p>
			</td>
		</tr>
	</table>
</div>

<div id="main-body">
<div id="left">
<div class="container">
	<ul>
		<li><b>Project</b>
		<li><a href="about.php">About</a>
		<li><a href="https://sourceforge.net/project/screenshots.php?group_id=152825">Screenshots</a>
		<li><a href="case-study.php">Case Study</a>
		<li><a href="roadmap.php">Roadmap</a>
		<li><a href="contributing.php">Contributing</a>
		<li><a href="development.php">Development</a>
		<li><b>Downloads</b>
		<li><a href="download.php">StarUML Download</a>
		<li><a href="modules.php">Modules</a>
		<li><a href="templates.php">Templates</a>
		<li><b>Support</b>
		<li><a href="https://sourceforge.net/forum/?group_id=152825">Forum</a>
		<li><a href="documentations.php">Documentations</a>
		<li><a href="articles.php">Articles</a>		
		<li><a href="commercial-support.php">Commercial Support</a>
		<li><a href="links.php">Links</a>
	</ul>
</div>
<br>
<div class="container" align="center">
<b>New Book</b><br>
<a href="http://www.lulu.com/content/1221482">Generating MS-Word Document with StarUML</a><br>
<a href="http://www.lulu.com/content/1221482"><img src="../image/worddocgenbook.jpg" class="icon"></a>
</div>
<br>
<script type="text/javascript"><!--
google_ad_client = "pub-2992470876807993";
google_ad_width = 160;
google_ad_height = 90;
google_ad_format = "160x90_0ads_al";
google_ad_channel = "";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

</div>
<div id="content">
	<H1>Case Study</H1>
	<P>There are several large-scale case study&nbsp;using StarUML.</P>
	<H4>ETRI -&nbsp;MCE (Mission Control Element&nbsp;for Satellite) </H4>
	<P>ETRI(Electronics and Telecommunications Research Institute) is the largest R&amp;D institute in Korea and it is one of internationally authoritative R&amp;D institutes. ETRI built KOMPSAT-2(1 meter-leveled low earth orbit satellites) with KARI(Korea Aerospace Research Institute), and ETRI was responsible for MCE part for controlling and monitoring the satellite from the earth. MCE consists of SOS(Satellite Operation System, SIM(Simulator) and MAPS(Mission Analysis and Planning System). ETRI succeeded this project and finished the preparation for launching a satellite in 2005 as adopting StarUML to design all of these systems. ETRI selected StarUML to design control system for geostationary communication satellite for next project. 
	<H4>SK Telecom - WCDMA NMS (Widearea-CDMA Network Management System)</H4>
	<P>SK Telecom is the largest mobile phone service provider. The market share of SK Telecom is 51.2%, and the company has customers over 19,000,000. WCDMA NMS is a managing system such as configurations management, performance management, security management, CDR Data Applications and other business supports about each NE(Network Element) to consist of wide area CDMA network. SK Telecom built WCDMA NMS system by using StarUML in 2003. </P>
	<H4>Asan Medical Center - OCS (Order Communication System) </H4>
	<P>Asan Medical Center is the largest medical treatment center in Korea. AMC treats 8000 outpatients, 2000 inpatients, 170 emergency patients daily, while also carrying out 150 advanced surgical operations per day, making it the busiest medical center in the country. AMC built OCS(Order Communication System) successfully by CBD(Component-Based Development) typed development methodology as adopting StarUML(formerly known as Plastic) in 2003.</P>
	<P>In addition, many universities, enterprises and public institution have been using StarUML, and the use of it has been spreading in many fields wildly.</P>
	<P>Please send us your case study or simply notify. It will encourage developers! </P>
</div>

<div id="right">
	<SCRIPT type=text/javascript><!--
	google_ad_client = "pub-2992470876807993";
	google_ad_width = 160;
	google_ad_height = 600;
	google_ad_format = "160x600_as";
	google_ad_type = "text_image";
	google_ad_channel ="";
	google_color_border = "336699";
	google_color_bg = "FFFFFF";
	google_color_link = "0000FF";
	google_color_url = "008000";
	google_color_text = "000000";
	//--></SCRIPT>
	
	<SCRIPT src="http://pagead2.googlesyndication.com/pagead/show_ads.js" type=text/javascript>
	</SCRIPT>
</div>

</div> <!-- of <div id="main-body"> -->
</div> <!-- of <div id="wrap"> -->

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-104513-2";
urchinTracker();
</script>

</body>
</html>









