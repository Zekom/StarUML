<html>
<head>
	<title>StarUML - ���¼ҽ� UML/MDA �÷���</title>
	<link rel="stylesheet" type="text/css" href="../css/staruml.css"/>
</head>
<body>

<div id="wrap">

<div id="header">
	<table width="100%">
		<tr>
			<td width="28%">
				<a href="index.php"><img src="../image/logo-staruml.gif"></a>
			</td width="28%">
			<td>
				<script type="text/javascript"><!--
				google_ad_client = "pub-2992470876807993";
				google_ad_width = 468;
				google_ad_height = 60;
				google_ad_format = "468x60_as";
				google_ad_type = "text_image";
				google_ad_channel ="";
				google_color_border = "6699CC";
				google_color_bg = "003366";
				google_color_link = "FFFFFF";
				google_color_text = "AECCEB";
				google_color_url = "AECCEB";
				//--></script>
				<script type="text/javascript"
				  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>
			</td>
			<td valign="top" align="right" style="padding: 15px 15px 15px 15px">
				<p><a href="../en/"><font color="white">����</font></a>
				<font color="white">| �ѱ���</font></p>
			</td>
		</tr>
	</table>
</div>

<div id="main-body">
<div id="left">
<div class="container">
	<ul>
		<li><b>������Ʈ</b>
		<li><a href="about.php">StarUML�����Ͽ�</a>
		<li><a href="license.php">���̼���</a>
		<li><a href="https://sourceforge.net/project/screenshots.php?group_id=152825">��ũ����</a>
		<li><a href="case-study.php">������</a>
		<li><a href="roadmap.php">�ε��</a>
		<li><a href="contributing.php">�����ϱ�</a>
		<li><b>�ٿ�ε�</b>
		<li><a href="download.php">StarUML�ٿ�ε�</a>
		<li><a href="modules.php">���</a>
		<li><a href="templates.php">���ø�</a>
		<li><b>����</b>
		<li><a href="forum.php">����/Ŀ�´�Ƽ</a>
		<li><a href="documentations.php">����ȭ</a>
		<li><a href="../en/articles.php">��ƼŬ</a>
		<li><a href="commercial-support.php">����� ����</a>
		<li><a href="links.php">���û���Ʈ</a>
	</ul>
</div>
<br>
<script type="text/javascript"><!--
google_ad_client = "pub-2992470876807993";
google_ad_width = 160;
google_ad_height = 90;
google_ad_format = "160x90_0ads_al";
google_ad_channel = "";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

</div>

<div id="content">
	<H1>��ũ</H1>
	<UL>
	<LI><A href="http://sourceforge.net/projects/staruml">�ҽ����� Ȩ (sourceforge.net/projects/staruml)</A> 
	</UL>
	<H2>���� ����Ʈ</H2>
	<UL>
	<LI><A href="http://www.omg.org">OMG(Object Management Group)</A></LI></UL>
</div>

<div id="right">
	<SCRIPT type=text/javascript><!--
	google_ad_client = "pub-2992470876807993";
	google_ad_width = 160;
	google_ad_height = 600;
	google_ad_format = "160x600_as";
	google_ad_type = "text_image";
	google_ad_channel ="";
	google_color_border = "336699";
	google_color_bg = "FFFFFF";
	google_color_link = "0000FF";
	google_color_url = "008000";
	google_color_text = "000000";
	//--></SCRIPT>
	
	<SCRIPT src="http://pagead2.googlesyndication.com/pagead/show_ads.js" type=text/javascript>
	</SCRIPT>
</div>

</div> <!-- of <div id="main-body"> -->
</div> <!-- of <div id="wrap"> -->
</body>
</html>

