AML Examples
Copyright � 2006 Whitestein Technologies. All rights reserved.

December 2006

A StarUML model of the AML modeling examples from:

   R. Cervenka and I.Trencansky. Agent Modeling Language: Language Specification. Version 0.9.
   Technical report, Whitestein Technologies, December 2004.
   URL: http://www.whitestein.com/pages/solutions/meth.html



Software Requirements:

* StarUML 5.0 or higher
* AML Profile for StarUML, version 0.9



Known Issue:

The error message "Could not convert variant of type (OleStr) into type (Double)" may occur when opening the model file. To fix this problem, the 'Standards and formats' settings in the 'Regional and Language Options' system dialog should be changed to "English (*)" (the Number field should be set to "123,456,789.00").



Support:

Please send support queries to the Whitestein administered AML mailing list. To subscribe, send an e-mail to sympa@lists.whitestein.com with 'subscribe aml-forum' (without the quotes) in the subject or the message body. If you have problems subscribing, please send an e-mail to listmaster@whitestein.com.

Requests for product information should be directed to the general information contact info@whitestein.com.